"""
Methods to load texts and keywords.
"""

def load_text(text_file_path):    
    text = []    
    with open(text_file_path) as f:
        text = f.read()
    
    return text


def load_keywords(keywords_file_path):
    keywords = []
    with open(keywords_file_path) as f:
        keywords = f.readlines()
        
    for i in range (len(keywords)):
        keywords[i] = keywords[i].replace("\n", "")
        
    return keywords