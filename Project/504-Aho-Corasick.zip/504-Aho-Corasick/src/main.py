"""
Main function to test Aho-Corasick algorithm.
"""

from data_loader import *
from aho_corasick import *


text_hp1_path = "../data/text_harry_potter_book_1.txt"
text_rainbow_path = "../data/text_rainbow.txt"

keywords_set1_path = "../data/keywords_set1.txt"


if __name__ == "__main__":
    text = load_text(text_rainbow_path)
    print(text)
    
    keywords = load_keywords(keywords_set1_path)
    print(keywords)
    