"""
Aho-Corasick algorithm to find patterns in a text is implemented here.
"""

def buildFSM(keywords):
    return 


def searchKeywords(text, keywords):
    return