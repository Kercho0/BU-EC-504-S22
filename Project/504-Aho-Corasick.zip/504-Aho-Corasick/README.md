# 504_project
EC 504 Final Project

src folder contains the source codes to run. main.py runs the program.
data folder contains the texts and the keywords.
